create
    definer = root@localhost procedure GETALLCITY(IN CTR varchar(20))
BEGIN
	select c.name from city as c
	left join  country as ctr on c.countrycode=ctr.code
	where ctr.name=ctr;
END;

